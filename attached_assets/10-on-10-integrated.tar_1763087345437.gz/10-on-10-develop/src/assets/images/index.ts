export const AUTH_LOGO = require("./AuthLogo.png")
