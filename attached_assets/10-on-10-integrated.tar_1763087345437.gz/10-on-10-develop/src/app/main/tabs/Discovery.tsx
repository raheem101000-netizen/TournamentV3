export { DiscoveryScreen as default } from '@/modules/discovery';
