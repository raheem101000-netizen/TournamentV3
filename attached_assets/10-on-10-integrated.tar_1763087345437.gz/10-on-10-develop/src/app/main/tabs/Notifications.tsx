export { NotificationsScreen as default } from '@/modules/notifications';
