import { StrictRouteParamsOutput } from "expo-router"

export type MainCreateEditProps = StrictRouteParamsOutput<"/main/[serverInfo]">
