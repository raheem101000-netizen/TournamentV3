export const IMAGE_SIZE = 56
export const SEPARATOR_SIZE = 16
