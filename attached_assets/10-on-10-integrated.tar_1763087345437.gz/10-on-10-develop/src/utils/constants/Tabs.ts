export enum NAVIGATION_TABS_TITLE {
  Home = "Home",
  Discovery = "Discovery",
  Messages = "Messages",
  Notifications = "Notifications",
  MyServers = "MyServers",
  Account = "Account",
}
