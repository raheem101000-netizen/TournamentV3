export enum ToastType {
  SUCCESS,
  WARNING,
  ERROR,
}
