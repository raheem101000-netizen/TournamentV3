export const DELETE_ACCOUNT_EMAIL =
  "10on10-delete-account-aaaapikjw5anexx2kpncxzglty@aexol.slack.com"
export const REPORT_USER_EMAIL = "10on10-report-user-aaaapjwmuoweiel2ksyumlqrkm@aexol.slack.com"
export const REPORT_SERVER_EMAIL = "10on10-report-server-aaaapiwt3p4spv4xxdy43gsrba@aexol.slack.com"
