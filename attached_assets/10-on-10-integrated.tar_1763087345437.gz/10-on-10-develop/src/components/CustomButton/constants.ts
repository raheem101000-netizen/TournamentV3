export enum CustomButtonVariants {
  STAND_ALONE,
  MAIN,
  SECONDARY,
}

export enum CustomButtonVersions {
  DEFAULT,
  POSITIVE,
  DANGER,
}
