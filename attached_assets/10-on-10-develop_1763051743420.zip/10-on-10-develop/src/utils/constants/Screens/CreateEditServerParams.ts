export enum CREATE_EDIT_PARAM {
  CREATE = "create",
}
