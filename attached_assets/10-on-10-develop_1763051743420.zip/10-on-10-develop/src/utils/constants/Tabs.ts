export enum NAVIGATION_TABS_TITLE {
  Home = "Home",
  MyServers = "MyServers",
  Account = "Account",
}
