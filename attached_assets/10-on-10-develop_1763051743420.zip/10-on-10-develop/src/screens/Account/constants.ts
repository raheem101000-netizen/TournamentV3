export enum ACCOUNT_CATEGORIES {
  ROLE = "Role",
  APP = "App",
}
