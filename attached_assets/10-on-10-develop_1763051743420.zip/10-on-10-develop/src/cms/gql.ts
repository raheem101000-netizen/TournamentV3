import { typedGql } from "./zeus/typedDocumentNode"

export const PRIVACY = typedGql("query")({
listpolicy:[{},{body:true}]
  })