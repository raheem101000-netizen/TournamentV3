import Errors from "./Errors.json"
import Success from "./Success.json"
import Warning from "./Warning.json"

export const Toast = {
  Errors,
  Success,
  Warning,
}
