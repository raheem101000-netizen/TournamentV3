import { TypePolicies } from "@apollo/client"

export const Server: TypePolicies = {
  Server: {
    merge: true,
  },
}
