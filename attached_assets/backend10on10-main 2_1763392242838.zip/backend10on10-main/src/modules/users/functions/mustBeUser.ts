import { getUserFromHandlerInput } from '@/src/modules/users/utils.js';

export const mustBeUser = getUserFromHandlerInput;
