import { createResolvers } from '@/src/modules/users/axolotl.js';

export default createResolvers({
  Mutation: {
    users: () => ({}),
  },
});
