/* eslint-disable */

import { AllTypesProps, ReturnTypes, Ops } from './const.js';
export const HOST = "https://10on10-cms.aexol.work/api/graphql"


export const HEADERS = {}
export const apiSubscription = (options: chainOptions) => (query: string) => {
  try {
    const queryString = options[0] + '?query=' + encodeURIComponent(query);
    const wsString = queryString.replace('http', 'ws');
    const host = (options.length > 1 && options[1]?.websocket?.[0]) || wsString;
    const webSocketOptions = options[1]?.websocket || [host];
    const ws = new WebSocket(...webSocketOptions);
    return {
      ws,
      on: (e: (args: any) => void) => {
        ws.onmessage = (event: any) => {
          if (event.data) {
            const parsed = JSON.parse(event.data);
            const data = parsed.data;
            return e(data);
          }
        };
      },
      off: (e: (args: any) => void) => {
        ws.onclose = e;
      },
      error: (e: (args: any) => void) => {
        ws.onerror = e;
      },
      open: (e: () => void) => {
        ws.onopen = e;
      },
    };
  } catch {
    throw new Error('No websockets implemented');
  }
};
const handleFetchResponse = (response: Response): Promise<GraphQLResponse> => {
  if (!response.ok) {
    return new Promise((_, reject) => {
      response
        .text()
        .then((text) => {
          try {
            reject(JSON.parse(text));
          } catch (err) {
            reject(text);
          }
        })
        .catch(reject);
    });
  }
  return response.json() as Promise<GraphQLResponse>;
};

export const apiFetch =
  (options: fetchOptions) =>
  (query: string, variables: Record<string, unknown> = {}) => {
    const fetchOptions = options[1] || {};
    if (fetchOptions.method && fetchOptions.method === 'GET') {
      return fetch(`${options[0]}?query=${encodeURIComponent(query)}`, fetchOptions)
        .then(handleFetchResponse)
        .then((response: GraphQLResponse) => {
          if (response.errors) {
            throw new GraphQLError(response);
          }
          return response.data;
        });
    }
    return fetch(`${options[0]}`, {
      body: JSON.stringify({ query, variables }),
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      ...fetchOptions,
    })
      .then(handleFetchResponse)
      .then((response: GraphQLResponse) => {
        if (response.errors) {
          throw new GraphQLError(response);
        }
        return response.data;
      });
  };

export const InternalsBuildQuery = ({
  ops,
  props,
  returns,
  options,
  scalars,
}: {
  props: AllTypesPropsType;
  returns: ReturnTypesType;
  ops: Operations;
  options?: OperationOptions;
  scalars?: ScalarDefinition;
}) => {
  const ibb = (
    k: string,
    o: InputValueType | VType,
    p = '',
    root = true,
    vars: Array<{ name: string; graphQLType: string }> = [],
  ): string => {
    const keyForPath = purifyGraphQLKey(k);
    const newPath = [p, keyForPath].join(SEPARATOR);
    if (!o) {
      return '';
    }
    if (typeof o === 'boolean' || typeof o === 'number') {
      return k;
    }
    if (typeof o === 'string') {
      return `${k} ${o}`;
    }
    if (Array.isArray(o)) {
      const args = InternalArgsBuilt({
        props,
        returns,
        ops,
        scalars,
        vars,
      })(o[0], newPath);
      return `${ibb(args ? `${k}(${args})` : k, o[1], p, false, vars)}`;
    }
    if (k === '__alias') {
      return Object.entries(o)
        .map(([alias, objectUnderAlias]) => {
          if (typeof objectUnderAlias !== 'object' || Array.isArray(objectUnderAlias)) {
            throw new Error(
              'Invalid alias it should be __alias:{ YOUR_ALIAS_NAME: { OPERATION_NAME: { ...selectors }}}',
            );
          }
          const operationName = Object.keys(objectUnderAlias)[0];
          const operation = objectUnderAlias[operationName];
          return ibb(`${alias}:${operationName}`, operation, p, false, vars);
        })
        .join('\n');
    }
    const hasOperationName = root && options?.operationName ? ' ' + options.operationName : '';
    const keyForDirectives = o.__directives ?? '';
    const query = `{${Object.entries(o)
      .filter(([k]) => k !== '__directives')
      .map((e) => ibb(...e, [p, `field<>${keyForPath}`].join(SEPARATOR), false, vars))
      .join('\n')}}`;
    if (!root) {
      return `${k} ${keyForDirectives}${hasOperationName} ${query}`;
    }
    const varsString = vars.map((v) => `${v.name}: ${v.graphQLType}`).join(', ');
    return `${k} ${keyForDirectives}${hasOperationName}${varsString ? `(${varsString})` : ''} ${query}`;
  };
  return ibb;
};

type UnionOverrideKeys<T, U> = Omit<T, keyof U> & U;

export const Thunder =
  <SCLR extends ScalarDefinition>(fn: FetchFunction, thunderGraphQLOptions?: ThunderGraphQLOptions<SCLR>) =>
  <O extends keyof typeof Ops, OVERRIDESCLR extends SCLR, R extends keyof ValueTypes = GenericOperation<O>>(
    operation: O,
    graphqlOptions?: ThunderGraphQLOptions<OVERRIDESCLR>,
  ) =>
  <Z extends ValueTypes[R]>(
    o: Z & {
      [P in keyof Z]: P extends keyof ValueTypes[R] ? Z[P] : never;
    },
    ops?: OperationOptions & { variables?: Record<string, unknown> },
  ) => {
    const options = {
      ...thunderGraphQLOptions,
      ...graphqlOptions,
    };
    return fn(
      Zeus(operation, o, {
        operationOptions: ops,
        scalars: options?.scalars,
      }),
      ops?.variables,
    ).then((data) => {
      if (options?.scalars) {
        return decodeScalarsInResponse({
          response: data,
          initialOp: operation,
          initialZeusQuery: o as VType,
          returns: ReturnTypes,
          scalars: options.scalars,
          ops: Ops,
        });
      }
      return data;
    }) as Promise<InputType<GraphQLTypes[R], Z, UnionOverrideKeys<SCLR, OVERRIDESCLR>>>;
  };

export const Chain = (...options: chainOptions) => Thunder(apiFetch(options));

export const SubscriptionThunder =
  <SCLR extends ScalarDefinition>(fn: SubscriptionFunction, thunderGraphQLOptions?: ThunderGraphQLOptions<SCLR>) =>
  <O extends keyof typeof Ops, OVERRIDESCLR extends SCLR, R extends keyof ValueTypes = GenericOperation<O>>(
    operation: O,
    graphqlOptions?: ThunderGraphQLOptions<OVERRIDESCLR>,
  ) =>
  <Z extends ValueTypes[R]>(
    o: Z & {
      [P in keyof Z]: P extends keyof ValueTypes[R] ? Z[P] : never;
    },
    ops?: OperationOptions & { variables?: ExtractVariables<Z> },
  ) => {
    const options = {
      ...thunderGraphQLOptions,
      ...graphqlOptions,
    };
    type CombinedSCLR = UnionOverrideKeys<SCLR, OVERRIDESCLR>;
    const returnedFunction = fn(
      Zeus(operation, o, {
        operationOptions: ops,
        scalars: options?.scalars,
      }),
    ) as SubscriptionToGraphQL<Z, GraphQLTypes[R], CombinedSCLR>;
    if (returnedFunction?.on && options?.scalars) {
      const wrapped = returnedFunction.on;
      returnedFunction.on = (fnToCall: (args: InputType<GraphQLTypes[R], Z, CombinedSCLR>) => void) =>
        wrapped((data: InputType<GraphQLTypes[R], Z, CombinedSCLR>) => {
          if (options?.scalars) {
            return fnToCall(
              decodeScalarsInResponse({
                response: data,
                initialOp: operation,
                initialZeusQuery: o as VType,
                returns: ReturnTypes,
                scalars: options.scalars,
                ops: Ops,
              }),
            );
          }
          return fnToCall(data);
        });
    }
    return returnedFunction;
  };

export const Subscription = (...options: chainOptions) => SubscriptionThunder(apiSubscription(options));
export const Zeus = <
  Z extends ValueTypes[R],
  O extends keyof typeof Ops,
  R extends keyof ValueTypes = GenericOperation<O>,
>(
  operation: O,
  o: Z,
  ops?: {
    operationOptions?: OperationOptions;
    scalars?: ScalarDefinition;
  },
) =>
  InternalsBuildQuery({
    props: AllTypesProps,
    returns: ReturnTypes,
    ops: Ops,
    options: ops?.operationOptions,
    scalars: ops?.scalars,
  })(operation, o as VType);

export const ZeusSelect = <T>() => ((t: unknown) => t) as SelectionFunction<T>;

export const Selector = <T extends keyof ValueTypes>(key: T) => key && ZeusSelect<ValueTypes[T]>();

export const TypeFromSelector = <T extends keyof ValueTypes>(key: T) => key && ZeusSelect<ValueTypes[T]>();
export const Gql = Chain(HOST, {
  headers: {
    'Content-Type': 'application/json',
    ...HEADERS,
  },
});

export const ZeusScalars = ZeusSelect<ScalarCoders>();

type ScalarsSelector<T> = {
  [X in Required<{
    [P in keyof T]: T[P] extends number | string | undefined | boolean ? P : never;
  }>[keyof T]]: true;
};

export const fields = <T extends keyof ModelTypes>(k: T) => {
  const t = ReturnTypes[k];
  const o = Object.fromEntries(
    Object.entries(t)
      .filter(([, value]) => {
        const isReturnType = ReturnTypes[value as string];
        if (!isReturnType || (typeof isReturnType === 'string' && isReturnType.startsWith('scalar.'))) {
          return true;
        }
      })
      .map(([key]) => [key, true as const]),
  );
  return o as ScalarsSelector<ModelTypes[T]>;
};

export const decodeScalarsInResponse = <O extends Operations>({
  response,
  scalars,
  returns,
  ops,
  initialZeusQuery,
  initialOp,
}: {
  ops: O;
  response: any;
  returns: ReturnTypesType;
  scalars?: Record<string, ScalarResolver | undefined>;
  initialOp: keyof O;
  initialZeusQuery: InputValueType | VType;
}) => {
  if (!scalars) {
    return response;
  }
  const builder = PrepareScalarPaths({
    ops,
    returns,
  });

  const scalarPaths = builder(initialOp as string, ops[initialOp], initialZeusQuery);
  if (scalarPaths) {
    const r = traverseResponse({ scalarPaths, resolvers: scalars })(initialOp as string, response, [ops[initialOp]]);
    return r;
  }
  return response;
};

export const traverseResponse = ({
  resolvers,
  scalarPaths,
}: {
  scalarPaths: { [x: string]: `scalar.${string}` };
  resolvers: {
    [x: string]: ScalarResolver | undefined;
  };
}) => {
  const ibb = (k: string, o: InputValueType | VType, p: string[] = []): unknown => {
    if (Array.isArray(o)) {
      return o.map((eachO) => ibb(k, eachO, p));
    }
    if (o == null) {
      return o;
    }
    const scalarPathString = p.join(SEPARATOR);
    const currentScalarString = scalarPaths[scalarPathString];
    if (currentScalarString) {
      const currentDecoder = resolvers[currentScalarString.split('.')[1]]?.decode;
      if (currentDecoder) {
        return currentDecoder(o);
      }
    }
    if (typeof o === 'boolean' || typeof o === 'number' || typeof o === 'string' || !o) {
      return o;
    }
    const entries = Object.entries(o).map(([k, v]) => [k, ibb(k, v, [...p, purifyGraphQLKey(k)])] as const);
    const objectFromEntries = entries.reduce<Record<string, unknown>>((a, [k, v]) => {
      a[k] = v;
      return a;
    }, {});
    return objectFromEntries;
  };
  return ibb;
};

export type AllTypesPropsType = {
  [x: string]:
    | undefined
    | `scalar.${string}`
    | 'enum'
    | {
        [x: string]:
          | undefined
          | string
          | {
              [x: string]: string | undefined;
            };
      };
};

export type ReturnTypesType = {
  [x: string]:
    | {
        [x: string]: string | undefined;
      }
    | `scalar.${string}`
    | undefined;
};
export type InputValueType = {
  [x: string]: undefined | boolean | string | number | [any, undefined | boolean | InputValueType] | InputValueType;
};
export type VType =
  | undefined
  | boolean
  | string
  | number
  | [any, undefined | boolean | InputValueType]
  | InputValueType;

export type PlainType = boolean | number | string | null | undefined;
export type ZeusArgsType =
  | PlainType
  | {
      [x: string]: ZeusArgsType;
    }
  | Array<ZeusArgsType>;

export type Operations = Record<string, string>;

export type VariableDefinition = {
  [x: string]: unknown;
};

export const SEPARATOR = '|';

export type fetchOptions = Parameters<typeof fetch>;
type websocketOptions = typeof WebSocket extends new (...args: infer R) => WebSocket ? R : never;
export type chainOptions = [fetchOptions[0], fetchOptions[1] & { websocket?: websocketOptions }] | [fetchOptions[0]];
export type FetchFunction = (query: string, variables?: Record<string, unknown>) => Promise<any>;
export type SubscriptionFunction = (query: string) => any;
type NotUndefined<T> = T extends undefined ? never : T;
export type ResolverType<F> = NotUndefined<F extends [infer ARGS, any] ? ARGS : undefined>;

export type OperationOptions = {
  operationName?: string;
};

export type ScalarCoder = Record<string, (s: unknown) => string>;

export interface GraphQLResponse {
  data?: Record<string, any>;
  errors?: Array<{
    message: string;
  }>;
}
export class GraphQLError extends Error {
  constructor(public response: GraphQLResponse) {
    super('');
    console.error(response);
  }
  toString() {
    return 'GraphQL Response Error';
  }
}
export type GenericOperation<O> = O extends keyof typeof Ops ? typeof Ops[O] : never;
export type ThunderGraphQLOptions<SCLR extends ScalarDefinition> = {
  scalars?: SCLR | ScalarCoders;
};

const ExtractScalar = (mappedParts: string[], returns: ReturnTypesType): `scalar.${string}` | undefined => {
  if (mappedParts.length === 0) {
    return;
  }
  const oKey = mappedParts[0];
  const returnP1 = returns[oKey];
  if (typeof returnP1 === 'object') {
    const returnP2 = returnP1[mappedParts[1]];
    if (returnP2) {
      return ExtractScalar([returnP2, ...mappedParts.slice(2)], returns);
    }
    return undefined;
  }
  return returnP1 as `scalar.${string}` | undefined;
};

export const PrepareScalarPaths = ({ ops, returns }: { returns: ReturnTypesType; ops: Operations }) => {
  const ibb = (
    k: string,
    originalKey: string,
    o: InputValueType | VType,
    p: string[] = [],
    pOriginals: string[] = [],
    root = true,
  ): { [x: string]: `scalar.${string}` } | undefined => {
    if (!o) {
      return;
    }
    if (typeof o === 'boolean' || typeof o === 'number' || typeof o === 'string') {
      const extractionArray = [...pOriginals, originalKey];
      const isScalar = ExtractScalar(extractionArray, returns);
      if (isScalar?.startsWith('scalar')) {
        const partOfTree = {
          [[...p, k].join(SEPARATOR)]: isScalar,
        };
        return partOfTree;
      }
      return {};
    }
    if (Array.isArray(o)) {
      return ibb(k, k, o[1], p, pOriginals, false);
    }
    if (k === '__alias') {
      return Object.entries(o)
        .map(([alias, objectUnderAlias]) => {
          if (typeof objectUnderAlias !== 'object' || Array.isArray(objectUnderAlias)) {
            throw new Error(
              'Invalid alias it should be __alias:{ YOUR_ALIAS_NAME: { OPERATION_NAME: { ...selectors }}}',
            );
          }
          const operationName = Object.keys(objectUnderAlias)[0];
          const operation = objectUnderAlias[operationName];
          return ibb(alias, operationName, operation, p, pOriginals, false);
        })
        .reduce((a, b) => ({
          ...a,
          ...b,
        }));
    }
    const keyName = root ? ops[k] : k;
    return Object.entries(o)
      .filter(([k]) => k !== '__directives')
      .map(([k, v]) => {
        // Inline fragments shouldn't be added to the path as they aren't a field
        const isInlineFragment = originalKey.match(/^...\s*on/) != null;
        return ibb(
          k,
          k,
          v,
          isInlineFragment ? p : [...p, purifyGraphQLKey(keyName || k)],
          isInlineFragment ? pOriginals : [...pOriginals, purifyGraphQLKey(originalKey)],
          false,
        );
      })
      .reduce((a, b) => ({
        ...a,
        ...b,
      }));
  };
  return ibb;
};

export const purifyGraphQLKey = (k: string) => k.replace(/\([^)]*\)/g, '').replace(/^[^:]*\:/g, '');

const mapPart = (p: string) => {
  const [isArg, isField] = p.split('<>');
  if (isField) {
    return {
      v: isField,
      __type: 'field',
    } as const;
  }
  return {
    v: isArg,
    __type: 'arg',
  } as const;
};

type Part = ReturnType<typeof mapPart>;

export const ResolveFromPath = (props: AllTypesPropsType, returns: ReturnTypesType, ops: Operations) => {
  const ResolvePropsType = (mappedParts: Part[]) => {
    const oKey = ops[mappedParts[0].v];
    const propsP1 = oKey ? props[oKey] : props[mappedParts[0].v];
    if (propsP1 === 'enum' && mappedParts.length === 1) {
      return 'enum';
    }
    if (typeof propsP1 === 'string' && propsP1.startsWith('scalar.') && mappedParts.length === 1) {
      return propsP1;
    }
    if (typeof propsP1 === 'object') {
      if (mappedParts.length < 2) {
        return 'not';
      }
      const propsP2 = propsP1[mappedParts[1].v];
      if (typeof propsP2 === 'string') {
        return rpp(
          `${propsP2}${SEPARATOR}${mappedParts
            .slice(2)
            .map((mp) => mp.v)
            .join(SEPARATOR)}`,
        );
      }
      if (typeof propsP2 === 'object') {
        if (mappedParts.length < 3) {
          return 'not';
        }
        const propsP3 = propsP2[mappedParts[2].v];
        if (propsP3 && mappedParts[2].__type === 'arg') {
          return rpp(
            `${propsP3}${SEPARATOR}${mappedParts
              .slice(3)
              .map((mp) => mp.v)
              .join(SEPARATOR)}`,
          );
        }
      }
    }
  };
  const ResolveReturnType = (mappedParts: Part[]) => {
    if (mappedParts.length === 0) {
      return 'not';
    }
    const oKey = ops[mappedParts[0].v];
    const returnP1 = oKey ? returns[oKey] : returns[mappedParts[0].v];
    if (typeof returnP1 === 'object') {
      if (mappedParts.length < 2) return 'not';
      const returnP2 = returnP1[mappedParts[1].v];
      if (returnP2) {
        return rpp(
          `${returnP2}${SEPARATOR}${mappedParts
            .slice(2)
            .map((mp) => mp.v)
            .join(SEPARATOR)}`,
        );
      }
    }
  };
  const rpp = (path: string): 'enum' | 'not' | `scalar.${string}` => {
    const parts = path.split(SEPARATOR).filter((l) => l.length > 0);
    const mappedParts = parts.map(mapPart);
    const propsP1 = ResolvePropsType(mappedParts);
    if (propsP1) {
      return propsP1;
    }
    const returnP1 = ResolveReturnType(mappedParts);
    if (returnP1) {
      return returnP1;
    }
    return 'not';
  };
  return rpp;
};

export const InternalArgsBuilt = ({
  props,
  ops,
  returns,
  scalars,
  vars,
}: {
  props: AllTypesPropsType;
  returns: ReturnTypesType;
  ops: Operations;
  scalars?: ScalarDefinition;
  vars: Array<{ name: string; graphQLType: string }>;
}) => {
  const arb = (a: ZeusArgsType, p = '', root = true): string => {
    if (typeof a === 'string') {
      if (a.startsWith(START_VAR_NAME)) {
        const [varName, graphQLType] = a.replace(START_VAR_NAME, '$').split(GRAPHQL_TYPE_SEPARATOR);
        const v = vars.find((v) => v.name === varName);
        if (!v) {
          vars.push({
            name: varName,
            graphQLType,
          });
        } else {
          if (v.graphQLType !== graphQLType) {
            throw new Error(
              `Invalid variable exists with two different GraphQL Types, "${v.graphQLType}" and ${graphQLType}`,
            );
          }
        }
        return varName;
      }
    }
    const checkType = ResolveFromPath(props, returns, ops)(p);
    if (checkType.startsWith('scalar.')) {
      // eslint-disable-next-line @typescript-eslint/no-unused-vars
      const [_, ...splittedScalar] = checkType.split('.');
      const scalarKey = splittedScalar.join('.');
      return (scalars?.[scalarKey]?.encode?.(a) as string) || JSON.stringify(a);
    }
    if (Array.isArray(a)) {
      return `[${a.map((arr) => arb(arr, p, false)).join(', ')}]`;
    }
    if (typeof a === 'string') {
      if (checkType === 'enum') {
        return a;
      }
      return `${JSON.stringify(a)}`;
    }
    if (typeof a === 'object') {
      if (a === null) {
        return `null`;
      }
      const returnedObjectString = Object.entries(a)
        .filter(([, v]) => typeof v !== 'undefined')
        .map(([k, v]) => `${k}: ${arb(v, [p, k].join(SEPARATOR), false)}`)
        .join(',\n');
      if (!root) {
        return `{${returnedObjectString}}`;
      }
      return returnedObjectString;
    }
    return `${a}`;
  };
  return arb;
};

export const resolverFor = <X, T extends keyof ResolverInputTypes, Z extends keyof ResolverInputTypes[T]>(
  type: T,
  field: Z,
  fn: (
    args: Required<ResolverInputTypes[T]>[Z] extends [infer Input, any] ? Input : any,
    source: any,
  ) => Z extends keyof ModelTypes[T] ? ModelTypes[T][Z] | Promise<ModelTypes[T][Z]> | X : never,
) => fn as (args?: any, source?: any) => ReturnType<typeof fn>;

export type UnwrapPromise<T> = T extends Promise<infer R> ? R : T;
export type ZeusState<T extends (...args: any[]) => Promise<any>> = NonNullable<UnwrapPromise<ReturnType<T>>>;
export type ZeusHook<
  T extends (...args: any[]) => Record<string, (...args: any[]) => Promise<any>>,
  N extends keyof ReturnType<T>,
> = ZeusState<ReturnType<T>[N]>;

export type WithTypeNameValue<T> = T & {
  __typename?: boolean;
  __directives?: string;
};
export type AliasType<T> = WithTypeNameValue<T> & {
  __alias?: Record<string, WithTypeNameValue<T>>;
};
type DeepAnify<T> = {
  [P in keyof T]?: any;
};
type IsPayLoad<T> = T extends [any, infer PayLoad] ? PayLoad : T;
export type ScalarDefinition = Record<string, ScalarResolver>;

type IsScalar<S, SCLR extends ScalarDefinition> = S extends 'scalar' & { name: infer T }
  ? T extends keyof SCLR
    ? SCLR[T]['decode'] extends (s: unknown) => unknown
      ? ReturnType<SCLR[T]['decode']>
      : unknown
    : unknown
  : S;
type IsArray<T, U, SCLR extends ScalarDefinition> = T extends Array<infer R>
  ? InputType<R, U, SCLR>[]
  : InputType<T, U, SCLR>;
type FlattenArray<T> = T extends Array<infer R> ? R : T;
type BaseZeusResolver = boolean | 1 | string | Variable<any, string>;

type IsInterfaced<SRC extends DeepAnify<DST>, DST, SCLR extends ScalarDefinition> = FlattenArray<SRC> extends
  | ZEUS_INTERFACES
  | ZEUS_UNIONS
  ? {
      [P in keyof SRC]: SRC[P] extends '__union' & infer R
        ? P extends keyof DST
          ? IsArray<R, '__typename' extends keyof DST ? DST[P] & { __typename: true } : DST[P], SCLR>
          : IsArray<R, '__typename' extends keyof DST ? { __typename: true } : Record<string, never>, SCLR>
        : never;
    }[keyof SRC] & {
      [P in keyof Omit<
        Pick<
          SRC,
          {
            [P in keyof DST]: SRC[P] extends '__union' & infer R ? never : P;
          }[keyof DST]
        >,
        '__typename'
      >]: IsPayLoad<DST[P]> extends BaseZeusResolver ? IsScalar<SRC[P], SCLR> : IsArray<SRC[P], DST[P], SCLR>;
    }
  : {
      [P in keyof Pick<SRC, keyof DST>]: IsPayLoad<DST[P]> extends BaseZeusResolver
        ? IsScalar<SRC[P], SCLR>
        : IsArray<SRC[P], DST[P], SCLR>;
    };

export type MapType<SRC, DST, SCLR extends ScalarDefinition> = SRC extends DeepAnify<DST>
  ? IsInterfaced<SRC, DST, SCLR>
  : never;
// eslint-disable-next-line @typescript-eslint/ban-types
export type InputType<SRC, DST, SCLR extends ScalarDefinition = {}> = IsPayLoad<DST> extends { __alias: infer R }
  ? {
      [P in keyof R]: MapType<SRC, R[P], SCLR>[keyof MapType<SRC, R[P], SCLR>];
    } & MapType<SRC, Omit<IsPayLoad<DST>, '__alias'>, SCLR>
  : MapType<SRC, IsPayLoad<DST>, SCLR>;
export type SubscriptionToGraphQL<Z, T, SCLR extends ScalarDefinition> = {
  ws: WebSocket;
  on: (fn: (args: InputType<T, Z, SCLR>) => void) => void;
  off: (fn: (e: { data?: InputType<T, Z, SCLR>; code?: number; reason?: string; message?: string }) => void) => void;
  error: (fn: (e: { data?: InputType<T, Z, SCLR>; errors?: string[] }) => void) => void;
  open: () => void;
};

// eslint-disable-next-line @typescript-eslint/ban-types
export type FromSelector<SELECTOR, NAME extends keyof GraphQLTypes, SCLR extends ScalarDefinition = {}> = InputType<
  GraphQLTypes[NAME],
  SELECTOR,
  SCLR
>;

export type ScalarResolver = {
  encode?: (s: unknown) => string;
  decode?: (s: unknown) => unknown;
};

export type SelectionFunction<V> = <Z extends V>(
  t: Z & {
    [P in keyof Z]: P extends keyof V ? Z[P] : never;
  },
) => Z;

type BuiltInVariableTypes = {
  ['String']: string;
  ['Int']: number;
  ['Float']: number;
  ['ID']: unknown;
  ['Boolean']: boolean;
};
type AllVariableTypes = keyof BuiltInVariableTypes | keyof ZEUS_VARIABLES;
type VariableRequired<T extends string> = `${T}!` | T | `[${T}]` | `[${T}]!` | `[${T}!]` | `[${T}!]!`;
type VR<T extends string> = VariableRequired<VariableRequired<T>>;

export type GraphQLVariableType = VR<AllVariableTypes>;

type ExtractVariableTypeString<T extends string> = T extends VR<infer R1>
  ? R1 extends VR<infer R2>
    ? R2 extends VR<infer R3>
      ? R3 extends VR<infer R4>
        ? R4 extends VR<infer R5>
          ? R5
          : R4
        : R3
      : R2
    : R1
  : T;

type DecomposeType<T, Type> = T extends `[${infer R}]`
  ? Array<DecomposeType<R, Type>> | undefined
  : T extends `${infer R}!`
  ? NonNullable<DecomposeType<R, Type>>
  : Type | undefined;

type ExtractTypeFromGraphQLType<T extends string> = T extends keyof ZEUS_VARIABLES
  ? ZEUS_VARIABLES[T]
  : T extends keyof BuiltInVariableTypes
  ? BuiltInVariableTypes[T]
  : any;

export type GetVariableType<T extends string> = DecomposeType<
  T,
  ExtractTypeFromGraphQLType<ExtractVariableTypeString<T>>
>;

type UndefinedKeys<T> = {
  [K in keyof T]-?: T[K] extends NonNullable<T[K]> ? never : K;
}[keyof T];

type WithNullableKeys<T> = Pick<T, UndefinedKeys<T>>;
type WithNonNullableKeys<T> = Omit<T, UndefinedKeys<T>>;

type OptionalKeys<T> = {
  [P in keyof T]?: T[P];
};

export type WithOptionalNullables<T> = OptionalKeys<WithNullableKeys<T>> & WithNonNullableKeys<T>;

export type Variable<T extends GraphQLVariableType, Name extends string> = {
  ' __zeus_name': Name;
  ' __zeus_type': T;
};

export type ExtractVariablesDeep<Query> = Query extends Variable<infer VType, infer VName>
  ? { [key in VName]: GetVariableType<VType> }
  : Query extends string | number | boolean | Array<string | number | boolean>
  ? // eslint-disable-next-line @typescript-eslint/ban-types
    {}
  : UnionToIntersection<{ [K in keyof Query]: WithOptionalNullables<ExtractVariablesDeep<Query[K]>> }[keyof Query]>;

export type ExtractVariables<Query> = Query extends Variable<infer VType, infer VName>
  ? { [key in VName]: GetVariableType<VType> }
  : Query extends [infer Inputs, infer Outputs]
  ? ExtractVariablesDeep<Inputs> & ExtractVariables<Outputs>
  : Query extends string | number | boolean | Array<string | number | boolean>
  ? // eslint-disable-next-line @typescript-eslint/ban-types
    {}
  : UnionToIntersection<{ [K in keyof Query]: WithOptionalNullables<ExtractVariables<Query[K]>> }[keyof Query]>;

type UnionToIntersection<U> = (U extends any ? (k: U) => void : never) extends (k: infer I) => void ? I : never;

export const START_VAR_NAME = `$ZEUS_VAR`;
export const GRAPHQL_TYPE_SEPARATOR = `__$GRAPHQL__`;

export const $ = <Type extends GraphQLVariableType, Name extends string>(name: Name, graphqlType: Type) => {
  return (START_VAR_NAME + name + GRAPHQL_TYPE_SEPARATOR + graphqlType) as unknown as Variable<Type, Name>;
};
type ZEUS_INTERFACES = never
export type ScalarCoders = {
	ModelNavigationCompiled?: ScalarResolver;
	ObjectId?: ScalarResolver;
	S3Scalar?: ScalarResolver;
	Timestamp?: ScalarResolver;
	BackupFile?: ScalarResolver;
}
type ZEUS_UNIONS = never

export type ValueTypes = {
    ["ModelNavigationCompiled"]:unknown;
	["ObjectId"]:unknown;
	["S3Scalar"]:unknown;
	["Timestamp"]:unknown;
	["ImageFieldInput"]: {
	thumbnail?: ValueTypes["S3Scalar"] | undefined | null | Variable<any, string>,
	url?: ValueTypes["S3Scalar"] | undefined | null | Variable<any, string>,
	alt?: string | undefined | null | Variable<any, string>
};
	["VersionField"]: AliasType<{
	name?:boolean | `@${string}`,
	from?:boolean | `@${string}`,
	to?:boolean | `@${string}`,
		__typename?: boolean | `@${string}`
}>;
	["ModifyVersion"]: {
	name?: string | undefined | null | Variable<any, string>,
	from?: ValueTypes["Timestamp"] | undefined | null | Variable<any, string>,
	to?: ValueTypes["Timestamp"] | undefined | null | Variable<any, string>
};
	["ImageField"]: AliasType<{
	url?:boolean | `@${string}`,
	thumbnail?:boolean | `@${string}`,
	alt?:boolean | `@${string}`,
		__typename?: boolean | `@${string}`
}>;
	["AnalyticsResponse"]: AliasType<{
	date?:boolean | `@${string}`,
	value?:ValueTypes["AnalyticsModelResponse"],
		__typename?: boolean | `@${string}`
}>;
	["AnalyticsModelResponse"]: AliasType<{
	modelName?:boolean | `@${string}`,
	calls?:boolean | `@${string}`,
	rootParamsKey?:boolean | `@${string}`,
		__typename?: boolean | `@${string}`
}>;
	["RootCMSParam"]: AliasType<{
	name?:boolean | `@${string}`,
	options?:boolean | `@${string}`,
		__typename?: boolean | `@${string}`
}>;
	["CreateRootCMSParam"]: {
	name: string | Variable<any, string>,
	options: Array<string> | Variable<any, string>
};
	["FileResponse"]: AliasType<{
	key?:boolean | `@${string}`,
	cdnURL?:boolean | `@${string}`,
		__typename?: boolean | `@${string}`
}>;
	["MediaResponse"]: AliasType<{
	key?:boolean | `@${string}`,
	cdnURL?:boolean | `@${string}`,
	thumbnailCdnURL?:boolean | `@${string}`,
	alt?:boolean | `@${string}`,
		__typename?: boolean | `@${string}`
}>;
	["UploadFileInput"]: {
	key: string | Variable<any, string>,
	prefix?: string | undefined | null | Variable<any, string>,
	alt?: string | undefined | null | Variable<any, string>
};
	["UploadFileResponseBase"]: AliasType<{
	key?:boolean | `@${string}`,
	putURL?:boolean | `@${string}`,
	cdnURL?:boolean | `@${string}`,
	alt?:boolean | `@${string}`,
		__typename?: boolean | `@${string}`
}>;
	["ImageUploadResponse"]: AliasType<{
	file?:ValueTypes["UploadFileResponseBase"],
	thumbnail?:ValueTypes["UploadFileResponseBase"],
		__typename?: boolean | `@${string}`
}>;
	["ModelNavigation"]: AliasType<{
	name?:boolean | `@${string}`,
	display?:boolean | `@${string}`,
	fields?:ValueTypes["CMSField"],
	fieldSet?:boolean | `@${string}`,
		__typename?: boolean | `@${string}`
}>;
	["CMSField"]: AliasType<{
	name?:boolean | `@${string}`,
	type?:boolean | `@${string}`,
	list?:boolean | `@${string}`,
	options?:boolean | `@${string}`,
	relation?:boolean | `@${string}`,
	fields?:ValueTypes["CMSField"],
	builtIn?:boolean | `@${string}`,
		__typename?: boolean | `@${string}`
}>;
	["InputCMSField"]: {
	name: string | Variable<any, string>,
	type: ValueTypes["CMSType"] | Variable<any, string>,
	list?: boolean | undefined | null | Variable<any, string>,
	options?: Array<string> | undefined | null | Variable<any, string>,
	relation?: string | undefined | null | Variable<any, string>,
	builtIn?: boolean | undefined | null | Variable<any, string>,
	fields?: Array<ValueTypes["InputCMSField"]> | undefined | null | Variable<any, string>
};
	["PageInfo"]: AliasType<{
	total?:boolean | `@${string}`,
	hasNext?:boolean | `@${string}`,
		__typename?: boolean | `@${string}`
}>;
	["ApiKey"]: AliasType<{
	name?:boolean | `@${string}`,
	createdAt?:boolean | `@${string}`,
	_id?:boolean | `@${string}`,
	value?:boolean | `@${string}`,
		__typename?: boolean | `@${string}`
}>;
	["PageInput"]: {
	limit: number | Variable<any, string>,
	start?: number | undefined | null | Variable<any, string>
};
	["BackupFile"]:unknown;
	["AdminQuery"]: AliasType<{
analytics?: [{	fromDate: string | Variable<any, string>,	toDate?: string | undefined | null | Variable<any, string>},ValueTypes["AnalyticsResponse"]],
	backup?:boolean | `@${string}`,
	backups?:ValueTypes["MediaResponse"],
	apiKeys?:ValueTypes["ApiKey"],
		__typename?: boolean | `@${string}`
}>;
	["Mutation"]: AliasType<{
	admin?:ValueTypes["AdminMutation"],
		__typename?: boolean | `@${string}`
}>;
	/** This enum is defined externally and injected via federation */
["CMSType"]:CMSType;
	["Query"]: AliasType<{
	admin?:ValueTypes["AdminQuery"],
	navigation?:ValueTypes["ModelNavigation"],
	migrateToCloud?:boolean | `@${string}`,
	isLoggedIn?:boolean | `@${string}`,
	rootParams?:ValueTypes["RootCMSParam"],
listcategory?: [{	rootParams?: ValueTypes["RootParamsInput"] | undefined | null | Variable<any, string>},ValueTypes["category"]],
listPaginatedcategory?: [{	page: ValueTypes["PageInput"] | Variable<any, string>,	rootParams?: ValueTypes["RootParamsInput"] | undefined | null | Variable<any, string>},ValueTypes["category__Connection"]],
onecategoryBySlug?: [{	slug: string | Variable<any, string>,	rootParams?: ValueTypes["RootParamsInput"] | undefined | null | Variable<any, string>},ValueTypes["category"]],
variantscategoryBySlug?: [{	slug: string | Variable<any, string>},ValueTypes["category"]],
	fieldSetcategory?:boolean | `@${string}`,
	modelcategory?:boolean | `@${string}`,
mediaQuery?: [{	model?: string | undefined | null | Variable<any, string>,	rootParams?: ValueTypes["RootParamsInput"] | undefined | null | Variable<any, string>},ValueTypes["MediaResponse"]],
filesQuery?: [{	rootParams?: ValueTypes["RootParamsInput"] | undefined | null | Variable<any, string>},ValueTypes["FileResponse"]],
		__typename?: boolean | `@${string}`
}>;
	["AdminMutation"]: AliasType<{
upsertModel?: [{	modelName?: string | undefined | null | Variable<any, string>,	fields: Array<ValueTypes["InputCMSField"]> | Variable<any, string>},boolean | `@${string}`],
removeModel?: [{	modelName: string | Variable<any, string>},boolean | `@${string}`],
upsertParam?: [{	param: ValueTypes["CreateRootCMSParam"] | Variable<any, string>},boolean | `@${string}`],
removeParam?: [{	name: string | Variable<any, string>},boolean | `@${string}`],
uploadFile?: [{	file: ValueTypes["UploadFileInput"] | Variable<any, string>},ValueTypes["UploadFileResponseBase"]],
uploadImage?: [{	file: ValueTypes["UploadFileInput"] | Variable<any, string>},ValueTypes["ImageUploadResponse"]],
removeFiles?: [{	keys: Array<string> | Variable<any, string>},boolean | `@${string}`],
restore?: [{	backup?: ValueTypes["BackupFile"] | undefined | null | Variable<any, string>},boolean | `@${string}`],
generateApiKey?: [{	name: string | Variable<any, string>},boolean | `@${string}`],
revokeApiKey?: [{	name: string | Variable<any, string>},boolean | `@${string}`],
upsertcategory?: [{	slug: string | Variable<any, string>,	category?: ValueTypes["Modifycategory"] | undefined | null | Variable<any, string>,	rootParams?: ValueTypes["RootParamsInput"] | undefined | null | Variable<any, string>},boolean | `@${string}`],
removecategory?: [{	slug: string | Variable<any, string>,	rootParams?: ValueTypes["RootParamsInput"] | undefined | null | Variable<any, string>},boolean | `@${string}`],
		__typename?: boolean | `@${string}`
}>;
	["category"]: AliasType<{
	_version?:ValueTypes["VersionField"],
	name?:boolean | `@${string}`,
	img?:ValueTypes["ImageField"],
	avatar?:ValueTypes["ImageField"],
	slug?:boolean | `@${string}`,
	_id?:boolean | `@${string}`,
		__typename?: boolean | `@${string}`
}>;
	["category__Connection"]: AliasType<{
	items?:ValueTypes["category"],
	pageInfo?:ValueTypes["PageInfo"],
		__typename?: boolean | `@${string}`
}>;
	["Modifycategory"]: {
	_version?: ValueTypes["ModifyVersion"] | undefined | null | Variable<any, string>,
	name?: string | undefined | null | Variable<any, string>,
	img?: ValueTypes["ImageFieldInput"] | undefined | null | Variable<any, string>,
	avatar?: ValueTypes["ImageFieldInput"] | undefined | null | Variable<any, string>,
	slug?: string | undefined | null | Variable<any, string>
};
	["RootParamsInput"]: {
	_version?: string | undefined | null | Variable<any, string>
}
  }

export type ResolverInputTypes = {
    ["ModelNavigationCompiled"]:unknown;
	["ObjectId"]:unknown;
	["S3Scalar"]:unknown;
	["Timestamp"]:unknown;
	["ImageFieldInput"]: {
	thumbnail?: ResolverInputTypes["S3Scalar"] | undefined | null,
	url?: ResolverInputTypes["S3Scalar"] | undefined | null,
	alt?: string | undefined | null
};
	["VersionField"]: AliasType<{
	name?:boolean | `@${string}`,
	from?:boolean | `@${string}`,
	to?:boolean | `@${string}`,
		__typename?: boolean | `@${string}`
}>;
	["ModifyVersion"]: {
	name?: string | undefined | null,
	from?: ResolverInputTypes["Timestamp"] | undefined | null,
	to?: ResolverInputTypes["Timestamp"] | undefined | null
};
	["ImageField"]: AliasType<{
	url?:boolean | `@${string}`,
	thumbnail?:boolean | `@${string}`,
	alt?:boolean | `@${string}`,
		__typename?: boolean | `@${string}`
}>;
	["AnalyticsResponse"]: AliasType<{
	date?:boolean | `@${string}`,
	value?:ResolverInputTypes["AnalyticsModelResponse"],
		__typename?: boolean | `@${string}`
}>;
	["AnalyticsModelResponse"]: AliasType<{
	modelName?:boolean | `@${string}`,
	calls?:boolean | `@${string}`,
	rootParamsKey?:boolean | `@${string}`,
		__typename?: boolean | `@${string}`
}>;
	["RootCMSParam"]: AliasType<{
	name?:boolean | `@${string}`,
	options?:boolean | `@${string}`,
		__typename?: boolean | `@${string}`
}>;
	["CreateRootCMSParam"]: {
	name: string,
	options: Array<string>
};
	["FileResponse"]: AliasType<{
	key?:boolean | `@${string}`,
	cdnURL?:boolean | `@${string}`,
		__typename?: boolean | `@${string}`
}>;
	["MediaResponse"]: AliasType<{
	key?:boolean | `@${string}`,
	cdnURL?:boolean | `@${string}`,
	thumbnailCdnURL?:boolean | `@${string}`,
	alt?:boolean | `@${string}`,
		__typename?: boolean | `@${string}`
}>;
	["UploadFileInput"]: {
	key: string,
	prefix?: string | undefined | null,
	alt?: string | undefined | null
};
	["UploadFileResponseBase"]: AliasType<{
	key?:boolean | `@${string}`,
	putURL?:boolean | `@${string}`,
	cdnURL?:boolean | `@${string}`,
	alt?:boolean | `@${string}`,
		__typename?: boolean | `@${string}`
}>;
	["ImageUploadResponse"]: AliasType<{
	file?:ResolverInputTypes["UploadFileResponseBase"],
	thumbnail?:ResolverInputTypes["UploadFileResponseBase"],
		__typename?: boolean | `@${string}`
}>;
	["ModelNavigation"]: AliasType<{
	name?:boolean | `@${string}`,
	display?:boolean | `@${string}`,
	fields?:ResolverInputTypes["CMSField"],
	fieldSet?:boolean | `@${string}`,
		__typename?: boolean | `@${string}`
}>;
	["CMSField"]: AliasType<{
	name?:boolean | `@${string}`,
	type?:boolean | `@${string}`,
	list?:boolean | `@${string}`,
	options?:boolean | `@${string}`,
	relation?:boolean | `@${string}`,
	fields?:ResolverInputTypes["CMSField"],
	builtIn?:boolean | `@${string}`,
		__typename?: boolean | `@${string}`
}>;
	["InputCMSField"]: {
	name: string,
	type: ResolverInputTypes["CMSType"],
	list?: boolean | undefined | null,
	options?: Array<string> | undefined | null,
	relation?: string | undefined | null,
	builtIn?: boolean | undefined | null,
	fields?: Array<ResolverInputTypes["InputCMSField"]> | undefined | null
};
	["PageInfo"]: AliasType<{
	total?:boolean | `@${string}`,
	hasNext?:boolean | `@${string}`,
		__typename?: boolean | `@${string}`
}>;
	["ApiKey"]: AliasType<{
	name?:boolean | `@${string}`,
	createdAt?:boolean | `@${string}`,
	_id?:boolean | `@${string}`,
	value?:boolean | `@${string}`,
		__typename?: boolean | `@${string}`
}>;
	["PageInput"]: {
	limit: number,
	start?: number | undefined | null
};
	["BackupFile"]:unknown;
	["AdminQuery"]: AliasType<{
analytics?: [{	fromDate: string,	toDate?: string | undefined | null},ResolverInputTypes["AnalyticsResponse"]],
	backup?:boolean | `@${string}`,
	backups?:ResolverInputTypes["MediaResponse"],
	apiKeys?:ResolverInputTypes["ApiKey"],
		__typename?: boolean | `@${string}`
}>;
	["Mutation"]: AliasType<{
	admin?:ResolverInputTypes["AdminMutation"],
		__typename?: boolean | `@${string}`
}>;
	/** This enum is defined externally and injected via federation */
["CMSType"]:CMSType;
	["Query"]: AliasType<{
	admin?:ResolverInputTypes["AdminQuery"],
	navigation?:ResolverInputTypes["ModelNavigation"],
	migrateToCloud?:boolean | `@${string}`,
	isLoggedIn?:boolean | `@${string}`,
	rootParams?:ResolverInputTypes["RootCMSParam"],
listcategory?: [{	rootParams?: ResolverInputTypes["RootParamsInput"] | undefined | null},ResolverInputTypes["category"]],
listPaginatedcategory?: [{	page: ResolverInputTypes["PageInput"],	rootParams?: ResolverInputTypes["RootParamsInput"] | undefined | null},ResolverInputTypes["category__Connection"]],
onecategoryBySlug?: [{	slug: string,	rootParams?: ResolverInputTypes["RootParamsInput"] | undefined | null},ResolverInputTypes["category"]],
variantscategoryBySlug?: [{	slug: string},ResolverInputTypes["category"]],
	fieldSetcategory?:boolean | `@${string}`,
	modelcategory?:boolean | `@${string}`,
mediaQuery?: [{	model?: string | undefined | null,	rootParams?: ResolverInputTypes["RootParamsInput"] | undefined | null},ResolverInputTypes["MediaResponse"]],
filesQuery?: [{	rootParams?: ResolverInputTypes["RootParamsInput"] | undefined | null},ResolverInputTypes["FileResponse"]],
		__typename?: boolean | `@${string}`
}>;
	["AdminMutation"]: AliasType<{
upsertModel?: [{	modelName?: string | undefined | null,	fields: Array<ResolverInputTypes["InputCMSField"]>},boolean | `@${string}`],
removeModel?: [{	modelName: string},boolean | `@${string}`],
upsertParam?: [{	param: ResolverInputTypes["CreateRootCMSParam"]},boolean | `@${string}`],
removeParam?: [{	name: string},boolean | `@${string}`],
uploadFile?: [{	file: ResolverInputTypes["UploadFileInput"]},ResolverInputTypes["UploadFileResponseBase"]],
uploadImage?: [{	file: ResolverInputTypes["UploadFileInput"]},ResolverInputTypes["ImageUploadResponse"]],
removeFiles?: [{	keys: Array<string>},boolean | `@${string}`],
restore?: [{	backup?: ResolverInputTypes["BackupFile"] | undefined | null},boolean | `@${string}`],
generateApiKey?: [{	name: string},boolean | `@${string}`],
revokeApiKey?: [{	name: string},boolean | `@${string}`],
upsertcategory?: [{	slug: string,	category?: ResolverInputTypes["Modifycategory"] | undefined | null,	rootParams?: ResolverInputTypes["RootParamsInput"] | undefined | null},boolean | `@${string}`],
removecategory?: [{	slug: string,	rootParams?: ResolverInputTypes["RootParamsInput"] | undefined | null},boolean | `@${string}`],
		__typename?: boolean | `@${string}`
}>;
	["category"]: AliasType<{
	_version?:ResolverInputTypes["VersionField"],
	name?:boolean | `@${string}`,
	img?:ResolverInputTypes["ImageField"],
	avatar?:ResolverInputTypes["ImageField"],
	slug?:boolean | `@${string}`,
	_id?:boolean | `@${string}`,
		__typename?: boolean | `@${string}`
}>;
	["category__Connection"]: AliasType<{
	items?:ResolverInputTypes["category"],
	pageInfo?:ResolverInputTypes["PageInfo"],
		__typename?: boolean | `@${string}`
}>;
	["Modifycategory"]: {
	_version?: ResolverInputTypes["ModifyVersion"] | undefined | null,
	name?: string | undefined | null,
	img?: ResolverInputTypes["ImageFieldInput"] | undefined | null,
	avatar?: ResolverInputTypes["ImageFieldInput"] | undefined | null,
	slug?: string | undefined | null
};
	["RootParamsInput"]: {
	_version?: string | undefined | null
};
	["schema"]: AliasType<{
	query?:ResolverInputTypes["Query"],
	mutation?:ResolverInputTypes["Mutation"],
		__typename?: boolean | `@${string}`
}>
  }

export type ModelTypes = {
    ["ModelNavigationCompiled"]:any;
	["ObjectId"]:any;
	["S3Scalar"]:any;
	["Timestamp"]:any;
	["ImageFieldInput"]: {
	thumbnail?: ModelTypes["S3Scalar"] | undefined,
	url?: ModelTypes["S3Scalar"] | undefined,
	alt?: string | undefined
};
	["VersionField"]: {
		name: string,
	from?: ModelTypes["Timestamp"] | undefined,
	to?: ModelTypes["Timestamp"] | undefined
};
	["ModifyVersion"]: {
	name?: string | undefined,
	from?: ModelTypes["Timestamp"] | undefined,
	to?: ModelTypes["Timestamp"] | undefined
};
	["ImageField"]: {
		url?: ModelTypes["S3Scalar"] | undefined,
	thumbnail?: ModelTypes["S3Scalar"] | undefined,
	alt?: string | undefined
};
	["AnalyticsResponse"]: {
		date?: string | undefined,
	value?: Array<ModelTypes["AnalyticsModelResponse"]> | undefined
};
	["AnalyticsModelResponse"]: {
		modelName: string,
	calls: number,
	rootParamsKey?: string | undefined
};
	["RootCMSParam"]: {
		name: string,
	options: Array<string>
};
	["CreateRootCMSParam"]: {
	name: string,
	options: Array<string>
};
	["FileResponse"]: {
		key: string,
	cdnURL: string
};
	["MediaResponse"]: {
		key?: string | undefined,
	cdnURL?: string | undefined,
	thumbnailCdnURL?: string | undefined,
	alt?: string | undefined
};
	["UploadFileInput"]: {
	key: string,
	prefix?: string | undefined,
	alt?: string | undefined
};
	["UploadFileResponseBase"]: {
		key: string,
	putURL: string,
	cdnURL: string,
	alt?: string | undefined
};
	["ImageUploadResponse"]: {
		file: ModelTypes["UploadFileResponseBase"],
	thumbnail: ModelTypes["UploadFileResponseBase"]
};
	["ModelNavigation"]: {
		name: string,
	display: string,
	fields: Array<ModelTypes["CMSField"]>,
	fieldSet: string
};
	["CMSField"]: {
		name: string,
	type: ModelTypes["CMSType"],
	list?: boolean | undefined,
	options?: Array<string> | undefined,
	relation?: string | undefined,
	fields?: Array<ModelTypes["CMSField"]> | undefined,
	builtIn?: boolean | undefined
};
	["InputCMSField"]: {
	name: string,
	type: ModelTypes["CMSType"],
	list?: boolean | undefined,
	options?: Array<string> | undefined,
	relation?: string | undefined,
	builtIn?: boolean | undefined,
	fields?: Array<ModelTypes["InputCMSField"]> | undefined
};
	["PageInfo"]: {
		total: number,
	hasNext?: boolean | undefined
};
	["ApiKey"]: {
		name: string,
	createdAt: string,
	_id: ModelTypes["ObjectId"],
	value: string
};
	["PageInput"]: {
	limit: number,
	start?: number | undefined
};
	["BackupFile"]:any;
	["AdminQuery"]: {
		analytics?: Array<ModelTypes["AnalyticsResponse"]> | undefined,
	backup?: boolean | undefined,
	backups?: Array<ModelTypes["MediaResponse"]> | undefined,
	apiKeys?: Array<ModelTypes["ApiKey"]> | undefined
};
	["Mutation"]: {
		admin?: ModelTypes["AdminMutation"] | undefined
};
	["CMSType"]:CMSType;
	["Query"]: {
		admin?: ModelTypes["AdminQuery"] | undefined,
	navigation?: Array<ModelTypes["ModelNavigation"]> | undefined,
	migrateToCloud?: string | undefined,
	isLoggedIn?: boolean | undefined,
	rootParams?: Array<ModelTypes["RootCMSParam"]> | undefined,
	listcategory?: Array<ModelTypes["category"]> | undefined,
	listPaginatedcategory?: ModelTypes["category__Connection"] | undefined,
	onecategoryBySlug?: ModelTypes["category"] | undefined,
	variantscategoryBySlug?: Array<ModelTypes["category"]> | undefined,
	fieldSetcategory: string,
	modelcategory: ModelTypes["ModelNavigationCompiled"],
	mediaQuery?: Array<ModelTypes["MediaResponse"]> | undefined,
	filesQuery?: Array<ModelTypes["FileResponse"]> | undefined
};
	["AdminMutation"]: {
		upsertModel?: boolean | undefined,
	removeModel?: boolean | undefined,
	upsertParam?: boolean | undefined,
	removeParam?: boolean | undefined,
	uploadFile?: ModelTypes["UploadFileResponseBase"] | undefined,
	uploadImage?: ModelTypes["ImageUploadResponse"] | undefined,
	removeFiles?: boolean | undefined,
	restore?: boolean | undefined,
	generateApiKey?: boolean | undefined,
	revokeApiKey?: boolean | undefined,
	upsertcategory?: boolean | undefined,
	removecategory?: boolean | undefined
};
	["category"]: {
		_version?: ModelTypes["VersionField"] | undefined,
	name?: string | undefined,
	img?: ModelTypes["ImageField"] | undefined,
	avatar?: ModelTypes["ImageField"] | undefined,
	slug?: string | undefined,
	_id: string
};
	["category__Connection"]: {
		items?: Array<ModelTypes["category"]> | undefined,
	pageInfo: ModelTypes["PageInfo"]
};
	["Modifycategory"]: {
	_version?: ModelTypes["ModifyVersion"] | undefined,
	name?: string | undefined,
	img?: ModelTypes["ImageFieldInput"] | undefined,
	avatar?: ModelTypes["ImageFieldInput"] | undefined,
	slug?: string | undefined
};
	["RootParamsInput"]: {
	_version?: string | undefined
};
	["schema"]: {
	query?: ModelTypes["Query"] | undefined,
	mutation?: ModelTypes["Mutation"] | undefined
}
    }

export type GraphQLTypes = {
    ["ModelNavigationCompiled"]: "scalar" & { name: "ModelNavigationCompiled" };
	["ObjectId"]: "scalar" & { name: "ObjectId" };
	["S3Scalar"]: "scalar" & { name: "S3Scalar" };
	["Timestamp"]: "scalar" & { name: "Timestamp" };
	["ImageFieldInput"]: {
		thumbnail?: GraphQLTypes["S3Scalar"] | undefined,
	url?: GraphQLTypes["S3Scalar"] | undefined,
	alt?: string | undefined
};
	["VersionField"]: {
	__typename: "VersionField",
	name: string,
	from?: GraphQLTypes["Timestamp"] | undefined,
	to?: GraphQLTypes["Timestamp"] | undefined
};
	["ModifyVersion"]: {
		name?: string | undefined,
	from?: GraphQLTypes["Timestamp"] | undefined,
	to?: GraphQLTypes["Timestamp"] | undefined
};
	["ImageField"]: {
	__typename: "ImageField",
	url?: GraphQLTypes["S3Scalar"] | undefined,
	thumbnail?: GraphQLTypes["S3Scalar"] | undefined,
	alt?: string | undefined
};
	["AnalyticsResponse"]: {
	__typename: "AnalyticsResponse",
	date?: string | undefined,
	value?: Array<GraphQLTypes["AnalyticsModelResponse"]> | undefined
};
	["AnalyticsModelResponse"]: {
	__typename: "AnalyticsModelResponse",
	modelName: string,
	calls: number,
	rootParamsKey?: string | undefined
};
	["RootCMSParam"]: {
	__typename: "RootCMSParam",
	name: string,
	options: Array<string>
};
	["CreateRootCMSParam"]: {
		name: string,
	options: Array<string>
};
	["FileResponse"]: {
	__typename: "FileResponse",
	key: string,
	cdnURL: string
};
	["MediaResponse"]: {
	__typename: "MediaResponse",
	key?: string | undefined,
	cdnURL?: string | undefined,
	thumbnailCdnURL?: string | undefined,
	alt?: string | undefined
};
	["UploadFileInput"]: {
		key: string,
	prefix?: string | undefined,
	alt?: string | undefined
};
	["UploadFileResponseBase"]: {
	__typename: "UploadFileResponseBase",
	key: string,
	putURL: string,
	cdnURL: string,
	alt?: string | undefined
};
	["ImageUploadResponse"]: {
	__typename: "ImageUploadResponse",
	file: GraphQLTypes["UploadFileResponseBase"],
	thumbnail: GraphQLTypes["UploadFileResponseBase"]
};
	["ModelNavigation"]: {
	__typename: "ModelNavigation",
	name: string,
	display: string,
	fields: Array<GraphQLTypes["CMSField"]>,
	fieldSet: string
};
	["CMSField"]: {
	__typename: "CMSField",
	name: string,
	type: GraphQLTypes["CMSType"],
	list?: boolean | undefined,
	options?: Array<string> | undefined,
	relation?: string | undefined,
	fields?: Array<GraphQLTypes["CMSField"]> | undefined,
	builtIn?: boolean | undefined
};
	["InputCMSField"]: {
		name: string,
	type: GraphQLTypes["CMSType"],
	list?: boolean | undefined,
	options?: Array<string> | undefined,
	relation?: string | undefined,
	builtIn?: boolean | undefined,
	fields?: Array<GraphQLTypes["InputCMSField"]> | undefined
};
	["PageInfo"]: {
	__typename: "PageInfo",
	total: number,
	hasNext?: boolean | undefined
};
	["ApiKey"]: {
	__typename: "ApiKey",
	name: string,
	createdAt: string,
	_id: GraphQLTypes["ObjectId"],
	value: string
};
	["PageInput"]: {
		limit: number,
	start?: number | undefined
};
	["BackupFile"]: "scalar" & { name: "BackupFile" };
	["AdminQuery"]: {
	__typename: "AdminQuery",
	analytics?: Array<GraphQLTypes["AnalyticsResponse"]> | undefined,
	backup?: boolean | undefined,
	backups?: Array<GraphQLTypes["MediaResponse"]> | undefined,
	apiKeys?: Array<GraphQLTypes["ApiKey"]> | undefined
};
	["Mutation"]: {
	__typename: "Mutation",
	admin?: GraphQLTypes["AdminMutation"] | undefined
};
	/** This enum is defined externally and injected via federation */
["CMSType"]: CMSType;
	["Query"]: {
	__typename: "Query",
	admin?: GraphQLTypes["AdminQuery"] | undefined,
	navigation?: Array<GraphQLTypes["ModelNavigation"]> | undefined,
	migrateToCloud?: string | undefined,
	isLoggedIn?: boolean | undefined,
	rootParams?: Array<GraphQLTypes["RootCMSParam"]> | undefined,
	listcategory?: Array<GraphQLTypes["category"]> | undefined,
	listPaginatedcategory?: GraphQLTypes["category__Connection"] | undefined,
	onecategoryBySlug?: GraphQLTypes["category"] | undefined,
	variantscategoryBySlug?: Array<GraphQLTypes["category"]> | undefined,
	fieldSetcategory: string,
	modelcategory: GraphQLTypes["ModelNavigationCompiled"],
	mediaQuery?: Array<GraphQLTypes["MediaResponse"]> | undefined,
	filesQuery?: Array<GraphQLTypes["FileResponse"]> | undefined
};
	["AdminMutation"]: {
	__typename: "AdminMutation",
	upsertModel?: boolean | undefined,
	removeModel?: boolean | undefined,
	upsertParam?: boolean | undefined,
	removeParam?: boolean | undefined,
	uploadFile?: GraphQLTypes["UploadFileResponseBase"] | undefined,
	uploadImage?: GraphQLTypes["ImageUploadResponse"] | undefined,
	removeFiles?: boolean | undefined,
	restore?: boolean | undefined,
	generateApiKey?: boolean | undefined,
	revokeApiKey?: boolean | undefined,
	upsertcategory?: boolean | undefined,
	removecategory?: boolean | undefined
};
	["category"]: {
	__typename: "category",
	_version?: GraphQLTypes["VersionField"] | undefined,
	name?: string | undefined,
	img?: GraphQLTypes["ImageField"] | undefined,
	avatar?: GraphQLTypes["ImageField"] | undefined,
	slug?: string | undefined,
	_id: string
};
	["category__Connection"]: {
	__typename: "category__Connection",
	items?: Array<GraphQLTypes["category"]> | undefined,
	pageInfo: GraphQLTypes["PageInfo"]
};
	["Modifycategory"]: {
		_version?: GraphQLTypes["ModifyVersion"] | undefined,
	name?: string | undefined,
	img?: GraphQLTypes["ImageFieldInput"] | undefined,
	avatar?: GraphQLTypes["ImageFieldInput"] | undefined,
	slug?: string | undefined
};
	["RootParamsInput"]: {
		_version?: string | undefined
}
    }
/** This enum is defined externally and injected via federation */
export const enum CMSType {
	STRING = "STRING",
	TITLE = "TITLE",
	NUMBER = "NUMBER",
	BOOLEAN = "BOOLEAN",
	DATE = "DATE",
	IMAGE = "IMAGE",
	CONTENT = "CONTENT",
	ERROR = "ERROR",
	IMAGE_URL = "IMAGE_URL",
	FILE = "FILE",
	RELATION = "RELATION",
	SELECT = "SELECT",
	OBJECT = "OBJECT",
	OBJECT_TABS = "OBJECT_TABS"
}

type ZEUS_VARIABLES = {
	["ModelNavigationCompiled"]: ValueTypes["ModelNavigationCompiled"];
	["ObjectId"]: ValueTypes["ObjectId"];
	["S3Scalar"]: ValueTypes["S3Scalar"];
	["Timestamp"]: ValueTypes["Timestamp"];
	["ImageFieldInput"]: ValueTypes["ImageFieldInput"];
	["ModifyVersion"]: ValueTypes["ModifyVersion"];
	["CreateRootCMSParam"]: ValueTypes["CreateRootCMSParam"];
	["UploadFileInput"]: ValueTypes["UploadFileInput"];
	["InputCMSField"]: ValueTypes["InputCMSField"];
	["PageInput"]: ValueTypes["PageInput"];
	["BackupFile"]: ValueTypes["BackupFile"];
	["CMSType"]: ValueTypes["CMSType"];
	["Modifycategory"]: ValueTypes["Modifycategory"];
	["RootParamsInput"]: ValueTypes["RootParamsInput"];
}